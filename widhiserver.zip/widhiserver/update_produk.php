<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");

include "db.php";
if (isset($_POST['update'])) {
    $id_barang = $_POST['id_barang'];
    $nama_br = $_POST['nama_br'];
    $hrgasewa = $_POST['hrgasewa '];
    $lamasewa = $_POST['lamasewa'];
   

    require_once("db.php");
    $q = mysqli_query($con, "UPDATE `tb_sewa` SET `nama_br`='$nama_br',`hrgasewa`='$hrgasewa',`lamasewa`='$lamasewa' where `id_barang`='$id_barang'");
    if ($q)
        echo "success";
    else
        echo "error";
}
