<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id9138677_widhi","123456","id9138677_widhi") or die ("could not connect database");
