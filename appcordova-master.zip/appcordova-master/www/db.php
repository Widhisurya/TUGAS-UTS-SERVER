<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","123456","id9138677_widhi","id9138677_widhi") or die ("could not connect database");
?>